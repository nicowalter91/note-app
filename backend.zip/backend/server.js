require("dotenv").config();
const config = require("./config.json");
const multer = require("multer");
const path = require("path");
const express = require("express");
const cors = require("cors");
const { authenticateToken } = require("./utilities");

// CORS Konfiguration
const corsOptions = {
    origin: 'http://localhost:5173',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Content-Length', 'X-Requested-With'],
    exposedHeaders: ['Content-Length', 'X-Requested-With'],
    optionsSuccessStatus: 200
};

// ** Datenbankverbindung **
const connectDB = require("./config/db");
connectDB();

// ** Controller-Importe **
const {
    addExercise, 
    editExercise, 
    getExercises, 
    deleteExercise, 
    searchExercises, 
    isPinnedExercise 
} = require("./controllers/exercises");

const { 
    addNote, 
    editNote, 
    getNotes, 
    deleteNote, 
    isPinned, 
    searchNote 
} = require("./controllers/notes");

const { 
    addPlayer,
    editPlayer,
    deletePlayer,
    getAllPlayers,
    getPlayer,
    updateAttendance,
    updateStrengthsAndWeaknesses,
    addDevelopmentGoal,
    updateDevelopmentGoal,
    deleteDevelopmentGoal,
    addInjury,
    updateInjury,
    deleteInjury,
    updatePerformanceMetrics
} = require("./controllers/players");

const { 
    getUser, 
    loginUser, 
    createUser 
} = require("./controllers/user");

const {
    createEvent,
    getEvents,
    updateEvent,
    deleteEvent
} = require("./controllers/events");

// Express-App initialisieren
const app = express();

// Middleware
app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Statische Dateien
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ** Multer-Konfiguration **
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "./uploads"));
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});

const upload = multer({ 
  storage, 
  fileFilter: (req, file, cb) => {
    const fileTypes = /jpeg|jpg|png|pdf/; // Added PDF for receipts
    const mimetype = fileTypes.test(file.mimetype);
    const extname = fileTypes.test(path.extname(file.originalname).toLowerCase());

    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error("Nur Bilder und PDF-Dateien sind erlaubt!"));
  }
});

// ** Statische Route für Bildzugriff **
app.use("/uploads", express.static(path.join(__dirname, "/uploads")));

// Routes importieren
const transactionsRoutes = require("./routes/transactions");
const clubRoutes = require("./routes/club");
const { updateProfileImage } = require("./controllers/players");

// ** Benutzerverwaltungsrouten **
app.post("/create-account", createUser);
app.post("/login", loginUser);
app.get("/get-user", authenticateToken, getUser);

// ** Notizverwaltungsrouten **
app.post("/add-note", authenticateToken, addNote);
app.put("/edit-note/:noteId", authenticateToken, editNote);
app.get("/get-all-notes", authenticateToken, getNotes);
app.delete("/delete-note/:noteId", authenticateToken, deleteNote);
app.put("/update-note-pinned/:noteId", authenticateToken, isPinned);
app.get("/search-notes", authenticateToken, searchNote);

// ** Übungsverwaltungsrouten **
app.post("/add-exercise", authenticateToken, upload.single("image"), addExercise);
app.put("/edit-exercise/:exerciseId", authenticateToken, upload.single("image"), editExercise);
app.get("/get-all-exercises", authenticateToken, getExercises);
app.delete("/delete-exercise/:exerciseId", authenticateToken, deleteExercise);
app.put("/update-exercise-pinned/:exerciseId", authenticateToken, isPinnedExercise);
app.get("/search-exercises", authenticateToken, searchExercises);

// ** Spielerverwaltungsrouten **
app.post("/add-player", authenticateToken, (req, res, next) => {
  console.log('Request headers:', req.headers);
  console.log('Request body:', req.body);
  next();
}, addPlayer);
app.put("/edit-player/:playerId", authenticateToken, editPlayer);
app.get("/get-all-players", authenticateToken, getAllPlayers);
app.get("/get-player/:playerId", authenticateToken, getPlayer);
app.delete("/delete-player/:playerId", authenticateToken, deletePlayer);
app.put("/update-attendance/:playerId", authenticateToken, updateAttendance);
app.put("/update-strengths/:playerId", authenticateToken, updateStrengthsAndWeaknesses);
app.post("/add-development-goal/:playerId", authenticateToken, addDevelopmentGoal);
app.put("/update-development-goal/:playerId/:goalId", authenticateToken, updateDevelopmentGoal);
app.delete("/delete-development-goal/:playerId/:goalId", authenticateToken, deleteDevelopmentGoal);
app.post("/add-injury/:playerId", authenticateToken, addInjury);
app.put("/update-injury/:playerId/:injuryId", authenticateToken, updateInjury);
app.delete("/delete-injury/:playerId/:injuryId", authenticateToken, deleteInjury);
app.put("/update-performance/:playerId", authenticateToken, updatePerformanceMetrics);
app.put("/update-profile-image/:playerId", authenticateToken, updateProfileImage);

// Club Routes
app.use('/', clubRoutes);

// Transaction Routes
app.use('/transactions', transactionsRoutes);

// ** Event-Management Routen **
app.post("/events", authenticateToken, createEvent);
app.get("/events", authenticateToken, getEvents);
app.put("/events/:eventId", authenticateToken, updateEvent);
app.delete("/events/:eventId", authenticateToken, deleteEvent);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    message: 'Ein Fehler ist aufgetreten',
    error: process.env.NODE_ENV === 'development' ? err.message : 'Internal Server Error'
  });
});

// ** Starten des Servers **
app.listen(8000, () => console.log("Server running on port 8000"));

module.exports = app;
