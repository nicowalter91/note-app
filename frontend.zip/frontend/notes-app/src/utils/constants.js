// Definiert die Basis-URL für die API-Anfragen.
// Diese URL wird als Grundlage für alle HTTP-Anfragen in der Anwendung verwendet.
export const BASE_URL = 'http://localhost:8000';
